The code implements the covasim and SIR model with vaccinations and age based mortality rates.
The `/SRC/utils` folder contains the implementations of different vaccine node selection algorithms and other graph utilities.

The `/SRC/covasim_implementation.py` has the parallel implementation of covasim model for given scenarios.

The `/SRC/sir_implementation.py` has the implementation for the SIR compartmental model for given scenarios.

All the data used for the simulations is within the `/SRC/data` folder

Steps to run the project:
1. Download all the dependencies by running the command in `/SRC/requirements.txt`
2. Once all the requirements are done, run `/SRC/covasim_runnable.py` to run the covasim model and `/SRC/sir_runnable.py` to run the SIR compartmental model. You change the initial parameters and the datasets in the files.


