The code implements the covasim and SIR model with vaccinations and age based mortality rates
The utils folder conatins the implmentations of different vaccine node selection algorithms and other graph utilities

The covasim_implementaion has the parallel implementation of covasim model for given scenarios

The sir_implmentation has the implementation for the SIR compatmental model for given scenarios

All the data used for the simulations is in the data folder

Steps to run the project:
1. Download all the depedencies by running the command in requirements.tx
2. Once all the requirements are done, run the covasim_runnable.py to run the covasim model and sir_runnable.py to run the SIR compartmental model. You change the initial parameters and the datasets in the files

