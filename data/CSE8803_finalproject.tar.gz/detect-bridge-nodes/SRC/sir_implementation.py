import os
import copy
import pickle
from pathlib import Path
from typing import Callable, List, Tuple, Dict

import numpy as np
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
import re
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing
import random
import time

import community.community_louvain as community_louvain
from utils.sir_utils import *

def plot_results(results: Dict, scenario_name: str, n_initial: int):
    """Plot cumulative infections and deaths."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    
    # Cumulative infections
    for algo_name, algo_results in results.items():
        ts = algo_results['time_series']
        ax1.plot(ts['day'], ts['cum_infections'], label=algo_name, linewidth=2)
    
    ax1.set_xlabel("Day")
    ax1.set_ylabel("Cumulative Infections")
    ax1.set_title(f"Cumulative Infections\n{scenario_name} | Initial: {n_initial}")
    ax1.legend(loc='best')
    ax1.grid(True, alpha=0.3)
    
    # Cumulative deaths
    for algo_name, algo_results in results.items():
        ts = algo_results['time_series']
        ax2.plot(ts['day'], ts['cum_deaths'], label=algo_name, linewidth=2)
    
    ax2.set_xlabel("Day")
    ax2.set_ylabel("Cumulative Deaths")
    ax2.set_title(f"Cumulative Deaths\n{scenario_name} | Initial: {n_initial}")
    ax2.legend(loc='best')
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.show()

class NetworkSIRModel:
    """
    Network-based SIR model with age-dependent mortality rates.
    
    States:
    - S: Susceptible
    - I: Infected
    - R: Recovered
    - D: Dead
    - V: Vaccinated (immune)
    """
    
    def __init__(self, G, ages, beta=0.05, gamma=0.1, age_mortality_rates=None, seed=42):
        """
        Initialize the network SIR model.
        
        Args:
            G: NetworkX graph with edges having 'weight' attribute
            ages: Dict mapping node_id to age (or array indexed by node_id)
            beta: Base transmission probability per contact
            gamma: Recovery rate (1/infectious_period)
            age_mortality_rates: Dict mapping age ranges to mortality rates
            seed: Random seed
        """
        self.G = G.copy()
        self.n_nodes = G.number_of_nodes()
        self.node_list = list(G.nodes())
        self.beta = beta
        self.gamma = gamma
        self.seed = seed
        
        np.random.seed(seed)
        random.seed(seed)
        
        # Convert ages to dict if it's an array
        if isinstance(ages, np.ndarray):
            self.ages = {node_id: ages[node_id] for node_id in self.node_list}
        else:
            self.ages = ages
        
        # Default age-dependent mortality rates (approximate COVID-19 IFR)
        if age_mortality_rates is None:
            self.age_mortality_rates = {
                (0, 17): 0.0001,    # 0.01%
                (18, 49): 0.0005,   # 0.05%
                (50, 64): 0.005,    # 0.5%
                (65, 74): 0.02,     # 2%
                (75, 120): 0.08     # 8%
            }
        else:
            self.age_mortality_rates = age_mortality_rates
        
        # Map each node to its mortality rate
        self.mortality_rates = {}
        for node_id in self.node_list:
            age = self.ages[node_id]
            for (low, high), rate in self.age_mortality_rates.items():
                if low <= age <= high:
                    self.mortality_rates[node_id] = rate
                    break
        
        # Initialize state dictionaries (using node IDs as keys)
        self.state = {node_id: 'S' for node_id in self.node_list}
        self.time_infected = {node_id: 0 for node_id in self.node_list}
        self.vaccinated = {node_id: False for node_id in self.node_list}
        
        # Results tracking
        self.results = {
            'day': [],
            'susceptible': [],
            'infected': [],
            'recovered': [],
            'dead': [],
            'vaccinated': [],
            'cum_infections': [],
            'cum_deaths': [],
            'cum_vaccinated': []
        }
        
        # Cumulative counters
        self.total_infections = 0
        self.total_deaths = 0
        self.total_vaccinated = 0
    
    def infect(self, node_ids):
        """Infect specific nodes."""
        for node_id in node_ids:
            if self.state[node_id] == 'S':
                self.state[node_id] = 'I'
                self.time_infected[node_id] = 0
                self.total_infections += 1
    
    def vaccinate(self, node_ids):
        """Vaccinate specific nodes."""
        for node_id in node_ids:
            if self.state[node_id] == 'S':
                self.state[node_id] = 'V'
                self.vaccinated[node_id] = True
                self.total_vaccinated += 1
    
    def step(self):
        """Execute one time step of the simulation."""
        new_state = self.state.copy()
        new_infections = []
        
        # Find all currently infected nodes
        infected_nodes = [node for node in self.node_list if self.state[node] == 'I']
        
        # Transmission: I -> S
        for infected_node in infected_nodes:
            neighbors = list(self.G.neighbors(infected_node))
            
            for neighbor in neighbors:
                if self.state[neighbor] == 'S':
                    weight = self.G[infected_node][neighbor].get('weight', 1.0)
                    
                    transmission_prob = self.beta * weight
                    
                    if np.random.random() < transmission_prob:
                        new_state[neighbor] = 'I'
                        new_infections.append(neighbor)
        
        for node in infected_nodes:
            self.time_infected[node] += 1
            
            if np.random.random() < self.gamma:
                if np.random.random() < self.mortality_rates[node]:
                    new_state[node] = 'D'
                    self.total_deaths += 1
                else:
                    new_state[node] = 'R'
        
        self.state = new_state
        
        self.total_infections += len(new_infections)
        
        self._record_results()
    
    def _record_results(self):
        """Record current state statistics."""
        counts = {
            'S': sum(1 for s in self.state.values() if s == 'S'),
            'I': sum(1 for s in self.state.values() if s == 'I'),
            'R': sum(1 for s in self.state.values() if s == 'R'),
            'D': sum(1 for s in self.state.values() if s == 'D'),
            'V': sum(1 for s in self.state.values() if s == 'V')
        }
        
        self.results['day'].append(len(self.results['day']))
        self.results['susceptible'].append(counts['S'])
        self.results['infected'].append(counts['I'])
        self.results['recovered'].append(counts['R'])
        self.results['dead'].append(counts['D'])
        self.results['vaccinated'].append(counts['V'])
        self.results['cum_infections'].append(self.total_infections)
        self.results['cum_deaths'].append(self.total_deaths)
        self.results['cum_vaccinated'].append(self.total_vaccinated)
    
    def run(self, n_days, initial_infections=None, vaccine_sequence=None, 
            daily_vaccines=0, verbose=False):
        """
        Run the simulation for n_days.
        
        Args:
            n_days: Number of days to simulate
            initial_infections: List of node IDs to infect initially
            vaccine_sequence: Ordered list of node IDs for vaccination priority
            daily_vaccines: Number of vaccines to administer per day
            verbose: Print progress
        """
        if initial_infections is not None:
            self.infect(initial_infections)
        
        self._record_results()
        
        vaccine_idx = 0
        
        for day in range(n_days):
            if verbose and day % 20 == 0:
                infected_count = sum(1 for s in self.state.values() if s == 'I')
                dead_count = sum(1 for s in self.state.values() if s == 'D')
                vacc_count = sum(1 for s in self.state.values() if s == 'V')
                print(f"Day {day}: I={infected_count}, D={dead_count}, V={vacc_count}")
            
            # Administer vaccines
            if vaccine_sequence is not None and daily_vaccines > 0:
                vaccines_today = 0
                while vaccines_today < daily_vaccines and vaccine_idx < len(vaccine_sequence):
                    node_id = vaccine_sequence[vaccine_idx]
                    if self.state[node_id] == 'S':
                        self.vaccinate([node_id])
                        vaccines_today += 1
                    vaccine_idx += 1
            
            self.step()
            
            infected_count = sum(1 for s in self.state.values() if s == 'I')
            if infected_count == 0:
                if verbose:
                    print(f"Epidemic ended at day {day}")
                # Fill remaining days with final state
                for _ in range(day + 1, n_days):
                    self._record_results()
                break
    
    def get_results_dataframe(self):
        """Return results as a pandas DataFrame."""
        return pd.DataFrame(self.results)

# --------------------------------------------------------------------------------
# EXPERIMENT FUNCTIONS
# --------------------------------------------------------------------------------

def precompute_vaccine_orderings(G: nx.Graph, ages: np.ndarray, 
                                 selection_algos: Dict[str, Callable]) -> Dict[str, np.ndarray]:
    """Compute vaccine orderings once for all algorithms."""
    print("Precomputing vaccine orderings...")
    orderings = {}
    
    # Get node list and create ages dict
    node_list = list(G.nodes())
    ages_dict = {node_id: ages[node_id] for node_id in node_list}
    
    for algo_name, algo_fn in selection_algos.items():
        print(f"  Computing ordering for: {algo_name}")
        start = time.time()
        
        if algo_name == "random":
            ordering = seq_random(node_list)
        elif algo_name == "age":
            ordering = prioritize_by_age(node_list, ages_dict)
        else:
            ordering = algo_fn()
        
        elapsed = time.time() - start
        orderings[algo_name] = ordering
        print(f"    Completed in {elapsed:.2f}s")
    
    return orderings

def run_one_scenario(G: nx.Graph, ages: np.ndarray, orderings: Dict[str, np.ndarray],
                     scenario: Dict, initial_infections: list, n_days: int = 120,
                     seed: int = 42) -> Dict:
    """Run all vaccine algorithms for one scenario."""
    start_time = time.time()
    
    scenario_name = scenario["name"]
    n_nodes = G.number_of_nodes()
    
    # Calculate daily vaccines based on scenario
    if scenario_name == "trickle":
        daily_vaccines = int(max(1, round(scenario["daily_pct"] * n_nodes)))
    elif scenario_name == "front_load":
        total_front_doses = int(round(scenario["front_pct"] * n_nodes))
        daily_vaccines = int(max(1, round(total_front_doses / scenario["front_days"])))
    else:
        daily_vaccines = 0
    
    # Run simulations for each algorithm
    results = {}
    
    for algo_name, ordering in orderings.items():
        # Set unique seed for this algorithm
        algo_seed = seed + hash(algo_name) % 10000
        
        # Create model
        model = NetworkSIRModel(G, ages, beta=0.05, gamma=0.1, seed=algo_seed)
        
        # Run simulation
        model.run(n_days=n_days, 
                 initial_infections=initial_infections,
                 vaccine_sequence=ordering if daily_vaccines > 0 else None,
                 daily_vaccines=daily_vaccines)
        
        # Store results
        results[algo_name] = {
            'cum_infections': model.results['cum_infections'][-1],
            'cum_deaths': model.results['cum_deaths'][-1],
            'cum_vaccinated': model.results['cum_vaccinated'][-1],
            'time_series': model.results
        }
    
    # Run no-vaccine baseline
    model_no = NetworkSIRModel(G, ages, beta=0.05, gamma=0.1, seed=seed)
    model_no.run(n_days=n_days, initial_infections=initial_infections,
                 vaccine_sequence=None, daily_vaccines=0)
    
    results["NoVax"] = {
        'cum_infections': model_no.results['cum_infections'][-1],
        'cum_deaths': model_no.results['cum_deaths'][-1],
        'cum_vaccinated': 0,
        'time_series': model_no.results
    }
    
    # Plot results
    plot_results(results, scenario_name, len(initial_infections))
    
    runtime = time.time() - start_time
    
    return {
        "scenario": scenario_name,
        "initial_infections": len(initial_infections),
        "results": results,
        "runtime_s": runtime
    }
