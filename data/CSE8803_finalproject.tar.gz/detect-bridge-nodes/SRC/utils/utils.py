import networkx as nx
import igraph as ig
import leidenalg
import os
import copy
import pickle
from pathlib import Path
from typing import Callable, List, Tuple, Dict

import numpy as np
import pandas as pd
import covasim as cv
import networkx as nx
import matplotlib.pyplot as plt
import re
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing
import random
import time
import community.community_louvain as community_louvain

def get_largest_community_leiden(nx_graph):
    """
    Detects communities using Leiden and returns nodes in the largest one.
    """
    g_igraph = ig.Graph.from_networkx(nx_graph)
    partition = leidenalg.find_partition(g_igraph, leidenalg.ModularityVertexPartition)
    largest_community_indices = max(partition, key=len)
    largest_community_nodes = [g_igraph.vs[i]['_nx_name'] for i in largest_community_indices]

    return largest_community_nodes

def get_community_map(G):
    """
    Detects communities using modularity maximization (Greedy approach).
    Returns:
     - communities_list: A list of sets (each set is a community)
     - community_map: A dictionary {node_id: community_id}
    """
    communities = nx.community.greedy_modularity_communities(G)
    
    community_map = {}
    communities_list = []
    
    for c_id, community in enumerate(communities):
        communities_list.append(community)
        for node in community:
            community_map[node] = c_id
            
    return communities_list, community_map

def rank_by_degree(G):
    """
    Simple approach - rank nodes by their degree (number of connections)
    High degree nodes can spread disease to more neighbors
    """
    degree_dict = dict(G.degree())
    sorted_by_degree = sorted(degree_dict.items(), key=lambda x: x[1], reverse=True)
    return [node for node, score in sorted_by_degree]

def bridge_hub_detector(G, num_walkers=200, max_steps=10):
    """
    Implements the Bridge-Hub Detector using Self-Avoiding Random Walks.
    """
    hub_scores = {n: 0 for n in G.nodes()}
    
    for i in range(num_walkers):
        current_node = random.choice(list(G.nodes()))
        visited_path = [current_node]
        
        for step in range(max_steps):
            neighbors = list(G.neighbors(current_node))
            valid_next_steps = [n for n in neighbors if n not in visited_path]
            
            if not valid_next_steps:
                break
            
            next_node = random.choice(valid_next_steps)
            next_neighbors = set(G.neighbors(next_node))
            visited_set = set(visited_path)
            
            connection_found = False
            for neighbor in next_neighbors:
                if neighbor in visited_set:
                    connection_found = True
                    break
            
            if not connection_found:
                hub_scores[next_node] += 1
                
            visited_path.append(next_node)
            current_node = next_node

    ranked_nodes = sorted(hub_scores.items(), key=lambda item: item[1], reverse=True)
    return [node for node, score in ranked_nodes]



def weighted_community_hub_bridge(G, alpha=0.7):
    """
    Calculates WCHB Centrality.
    Formula: Score = (1-alpha)*(Intra_Degree * Comm_Size) + alpha*(Inter_Degree * NNC)
    """
    comm_list, comm_map = get_community_map(G)
    scores = {}
    
    for node in G.nodes():
        node_comm_id = comm_map[node]
        node_comm_size = len(comm_list[node_comm_id])
        
        k_intra = 0
        k_inter = 0
        neighboring_comms = set()
        
        for neighbor in G.neighbors(node):
            if neighbor not in comm_map: continue
            
            neighbor_comm_id = comm_map[neighbor]
            
            if neighbor_comm_id == node_comm_id:
                k_intra += 1
            else:
                k_inter += 1
                neighboring_comms.add(neighbor_comm_id)
        
        nnc = len(neighboring_comms)
        hub_term = k_intra * node_comm_size
        bridge_term = k_inter * nnc
        scores[node] = ((1 - alpha) * hub_term) + (alpha * bridge_term)
        
    ranked_nodes = sorted(scores.items(), key=lambda item: item[1], reverse=True)
    return [node for node, score in ranked_nodes]

# --------------------------------------------------------------------------------
# STRATEGY 3: MODULARITY VITALITY (MV)
# --------------------------------------------------------------------------------
def modularity_vitality(G):
    """
    Calculates Modularity Vitality by simulating node removal.
    Vitality = Q_original - Q_removed
    """
    comm_list, comm_map = get_community_map(G)
    initial_Q = nx.community.modularity(G, comm_list)
    vitality_scores = {}
    
    nodes = list(G.nodes())
    for node in nodes:
        G_temp = G.copy()
        G_temp.remove_node(node)
        
        temp_comm_list = []
        for comm_set in comm_list:
            if node in comm_set:
                new_set = set(comm_set) 
                new_set.remove(node)
                if len(new_set) > 0:
                    temp_comm_list.append(new_set)
            else:
                temp_comm_list.append(comm_set)
        
        try:
            if len(G_temp.edges()) == 0:
                new_Q = 0
            else:
                new_Q = nx.community.modularity(G_temp, temp_comm_list)
        except:
            new_Q = 0
            
        vitality_scores[node] = initial_Q - new_Q
        
    ranked_nodes = sorted(vitality_scores.items(), key=lambda item: item[1])
    return [node for node, score in ranked_nodes]


def rank_by_community_bridge(G):
    """
    Find bridge nodes between communities using modularity-based detection
    """
    try:
        communities = community_louvain.best_partition(G)
    except:
        communities_list = list(nx.community.label_propagation_communities(G))
        communities = {}
        for i, comm in enumerate(communities_list):
            for node in comm:
                communities[node] = i
    
    bridge_scores = {}
    
    for node in G.nodes():
        node_community = communities[node]
        cross_community_edges = 0
        total_edges = 0
        connected_communities = set()
        
        for neighbor in G.neighbors(node):
            total_edges += 1
            neighbor_community = communities[neighbor]
            
            if neighbor_community != node_community:
                cross_community_edges += 1
                connected_communities.add(neighbor_community)
        
        if total_edges > 0:
            bridge_scores[node] = (cross_community_edges / total_edges) * len(connected_communities)
        else:
            bridge_scores[node] = 0
    
    ranked = sorted(bridge_scores.items(), key=lambda x: x[1], reverse=True)
    return [node for node, score in ranked]
