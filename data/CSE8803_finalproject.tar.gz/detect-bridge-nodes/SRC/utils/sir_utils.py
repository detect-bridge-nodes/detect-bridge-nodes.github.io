
from pathlib import Path
from typing import Callable, Dict

import numpy as np
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
import re
from concurrent.futures import ProcessPoolExecutor, as_completed
import random
import time
import community.community_louvain as community_louvain
from utils.utils import *

_GLOBAL_GRAPH = None

def set_global_graph(G: nx.Graph):
    """Set the global graph to be used by sequence functions"""
    global _GLOBAL_GRAPH
    _GLOBAL_GRAPH = G

def seq_random(node_list, seed=42):
    """Random permutation of node IDs"""
    rng = np.random.default_rng(seed)
    return rng.permutation(node_list)

def prioritize_by_age(node_list, ages_dict):
    """Prioritize by age (oldest first)"""
    # Sort nodes by age (descending)
    sorted_nodes = sorted(node_list, key=lambda n: -ages_dict[n])
    return np.array(sorted_nodes, dtype=int)

def seq_degree():
    """Wrapper for degree centrality - returns actual node IDs"""
    if _GLOBAL_GRAPH is None:
        raise ValueError("Global graph not set.")
    return np.array(rank_by_degree(_GLOBAL_GRAPH), dtype=int)

def seq_wchb():
    """Wrapper for weighted community hub-bridge - returns actual node IDs"""
    if _GLOBAL_GRAPH is None:
        raise ValueError("Global graph not set.")
    return np.array(weighted_community_hub_bridge(_GLOBAL_GRAPH), dtype=int)

def seq_bhd():
    """Wrapper for bridge-hub detector - returns actual node IDs"""
    if _GLOBAL_GRAPH is None:
        raise ValueError("Global graph not set.")
    return np.array(bridge_hub_detector(_GLOBAL_GRAPH), dtype=int)

def seq_mv():
    """Wrapper for modularity vitality - returns actual node IDs"""
    if _GLOBAL_GRAPH is None:
        raise ValueError("Global graph not set.")
    return np.array(modularity_vitality(_GLOBAL_GRAPH), dtype=int)

def seq_cb():
    """Wrapper for community bridge - returns actual node IDs"""
    if _GLOBAL_GRAPH is None:
        raise ValueError("Global graph not set.")
    return np.array(rank_by_community_bridge(_GLOBAL_GRAPH), dtype=int)

# --------------------------------------------------------------------------------
# GRAPH CONSTRUCTION
# --------------------------------------------------------------------------------

def build_graph_from_contacts(contacts_csv: str) -> nx.Graph:
    """Build a NetworkX graph from contacts CSV file."""
    print(f"Building graph from {contacts_csv}...")
    df_contacts = pd.read_csv(contacts_csv)
    df_contacts.columns = df_contacts.columns.str.strip()
    
    if 'PersonId1' in df_contacts.columns:
        df_contacts = df_contacts.rename(columns={'PersonId1': 'pid1', 'PersonId2': 'pid2'})
    
    G = nx.Graph()
    
    for _, row in df_contacts.iterrows():
        pid1 = int(row['pid1'])
        pid2 = int(row['pid2'])
        intensity = float(row['Intensity']) if 'Intensity' in row else 1.0
        
        if G.has_edge(pid1, pid2):
            G[pid1][pid2]['weight'] += intensity
        else:
            G.add_edge(pid1, pid2, weight=intensity)
    
    print(f"  Graph created: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")
    return G
