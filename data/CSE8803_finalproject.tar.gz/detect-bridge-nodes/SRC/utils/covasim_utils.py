import networkx as nx
import igraph as ig
import leidenalg
import copy
from typing import Callable, List, Dict
import numpy as np
import pandas as pd
import covasim as cv
import networkx as nx
import matplotlib.pyplot as plt
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing
import random
import time
import community.community_louvain as community_louvain
from utils.utils import *

_GLOBAL_GRAPH = None

def seq_random(people: cv.People) -> np.ndarray:
    """Random permutation of uids"""
    uids = np.array(people.uid, dtype=int)
    rng = np.random.default_rng(42)
    return rng.permutation(uids)

def prioritize_by_age(people):
    return np.argsort(-people.age)


def build_graph_from_contacts(contacts_csv: str) -> nx.Graph:
    """
    Build a NetworkX graph directly from the contacts CSV file.
    
    Args:
        contacts_csv: Path to contacts CSV file
    
    Returns:
        NetworkX Graph with nodes and weighted edges
    """
    print(f"Building graph from {contacts_csv}...")
    df_contacts = pd.read_csv(contacts_csv)
    df_contacts.columns = df_contacts.columns.str.strip()
    
    if 'PersonId1' in df_contacts.columns:
        df_contacts = df_contacts.rename(columns={'PersonId1': 'pid1', 'PersonId2': 'pid2'})
    
    G = nx.Graph()
    
    # Add edges with weights (using Intensity as weight)
    for _, row in df_contacts.iterrows():
        pid1 = int(row['pid1'])
        pid2 = int(row['pid2'])
        intensity = float(row['Intensity']) if 'Intensity' in row else 1.0
        
        # Add edge (if it exists, sum the weights for multiple connections)
        if G.has_edge(pid1, pid2):
            G[pid1][pid2]['weight'] += intensity
        else:
            G.add_edge(pid1, pid2, weight=intensity)
    
    print(f"  Graph created: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")
    return G

def set_global_graph(G: nx.Graph):
    """Set the global graph to be used by sequence functions"""
    global _GLOBAL_GRAPH
    _GLOBAL_GRAPH = G

# Wrapper functions for vaccination order

def seq_degree(people):
    """Wrapper for degree centrality using pre-built graph"""
    if _GLOBAL_GRAPH is None:
        raise ValueError("Global graph not set. Call set_global_graph() first.")
    ranking = rank_by_degree(_GLOBAL_GRAPH)
    return np.array(ranking, dtype=int)

def seq_wchb(people):
    """Wrapper for weighted community hub-bridge using pre-built graph"""
    if _GLOBAL_GRAPH is None:
        raise ValueError("Global graph not set. Call set_global_graph() first.")
    ranking = weighted_community_hub_bridge(_GLOBAL_GRAPH)
    return np.array(ranking, dtype=int)

def seq_bhd(people):
    """Wrapper for bridge-hub detector using pre-built graph"""
    if _GLOBAL_GRAPH is None:
        raise ValueError("Global graph not set. Call set_global_graph() first.")
    ranking = bridge_hub_detector(_GLOBAL_GRAPH)
    return np.array(ranking, dtype=int)

def seq_mv(people):
    """Wrapper for modularity vitality using pre-built graph"""
    if _GLOBAL_GRAPH is None:
        raise ValueError("Global graph not set. Call set_global_graph() first.")
    ranking = modularity_vitality(_GLOBAL_GRAPH)
    return np.array(ranking, dtype=int)

def seq_cb(people):
    """Wrapper for community bridge using pre-built graph"""
    if _GLOBAL_GRAPH is None:
        raise ValueError("Global graph not set. Call set_global_graph() first.")
    ranking = rank_by_community_bridge(_GLOBAL_GRAPH)
    return np.array(ranking, dtype=int)

