import networkx as nx
import igraph as ig
import leidenalg
import copy
from typing import Callable, List, Dict
import numpy as np
import pandas as pd
import covasim as cv
import networkx as nx
import matplotlib.pyplot as plt
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing
import random
import time
import community.community_louvain as community_louvain
from utils.covasim_utils import *

SELECTION_ALGOS = {
        "random": seq_random,
        "degree": seq_degree,
        "wchb": seq_wchb,
        "bhd": seq_bhd,
        "cb": seq_cb,
        "mv": seq_mv,
        "age": prioritize_by_age
    }
def precompute_vaccine_orderings(people: cv.People, selection_algos: Dict[str, Callable]) -> Dict[str, np.ndarray]:
    """
    Compute vaccine orderings once for all algorithms.
    
    Returns:
        Dict mapping algorithm name to ordered array of UIDs
    """
    print("Precomputing vaccine orderings...")
    orderings = {}
    
    for algo_name, algo_fn in selection_algos.items():
        print(f"  Computing ordering for: {algo_name}")
        start = time.time()
        ordering = algo_fn(people)
        elapsed = time.time() - start
        orderings[algo_name] = ordering
        print(f"    Completed in {elapsed:.2f}s")
    
    return orderings


# ---------------------------
# Build interventions using pre-computed orderings
# ---------------------------

def build_vaccine_interventions_with_ordering(ordering: np.ndarray, pop_size: int,
                                              scenario: str, daily_pct: float = None,
                                              front_pct: float = None, front_days: int = None,
                                              total_days: int = 120):
    """
    Build vaccine interventions using a pre-computed ordering.
    
    Instead of passing a function, we create a lambda that returns the fixed ordering.
    """
    # Create a function that returns the pre-computed ordering
    sequence_fn = lambda people: ordering
    
    interventions = []
    if scenario == "trickle":
        if daily_pct is None:
            raise ValueError("daily_pct required for trickle")
        daily_doses = int(max(1, round(daily_pct * pop_size)))
        interventions.append(cv.vaccinate_num(num_doses=daily_doses, vaccine="default",
                                              sequence=sequence_fn))
    elif scenario == "front_load":
        if front_pct is None or front_days is None:
            raise ValueError("front_pct and front_days required for front_load")
        total_front_doses = int(round(front_pct * pop_size))
        doses_per_day = int(max(1, round(total_front_doses / front_days)))
        interventions.append(cv.vaccinate_num(num_doses=doses_per_day, vaccine="default",
                                              sequence=sequence_fn))
    else:
        raise ValueError("Unknown scenario")
    return interventions



def run_one_initialization(people: cv.People,
                          orderings: Dict[str, np.ndarray],
                          scenario: Dict,
                          initial_infections: int,
                          n_days: int = 120,
                          seed: int = 42) -> Dict:
    """
    Run all vaccine algorithms in parallel for a single initialization.
    
    Args:
        people: The population
        orderings: Pre-computed vaccine orderings for each algorithm
        scenario: Dict with scenario configuration
        initial_infections: Number of initial infections
        n_days: Simulation days
        seed: Random seed
    
    Returns:
        Dictionary with results for all algorithms
    """
    start_time = time.time()
    
    # Set seed for reproducibility
    np.random.seed(seed)
    random.seed(seed)
    
    scenario_name = scenario["name"]
    pop_size = len(people.uid)
    
    
    if isinstance(initial_infections, (list, np.ndarray)):
        initial_inf_uids = np.array(initial_infections, dtype=int)
        pars = dict(pop_size=pop_size, pop_infected=0, n_days=n_days)
    else:
        pars = dict(pop_size=pop_size, pop_infected=initial_infections, n_days=n_days)

    sims = []
    algo_names = []
    
    for algo_name, ordering in orderings.items():
        people_copy = copy.deepcopy(people)
        
        # Build interventions using pre-computed ordering
        if scenario_name == "trickle":
            interventions = build_vaccine_interventions_with_ordering(
                ordering, pop_size,
                scenario="trickle",
                daily_pct=scenario["daily_pct"],
                total_days=n_days
            )
        else:  
            interventions = build_vaccine_interventions_with_ordering(
                ordering, pop_size,
                scenario="front_load",
                front_pct=scenario["front_pct"],
                front_days=scenario["front_days"],
                total_days=n_days
            )
        if isinstance(initial_infections, (list, np.ndarray)):
            init_label = f"community infection  {len(initial_infections)}"
        else:
            init_label = initial_infections
        label = f"{algo_name}__{scenario_name}__init{init_label}"
        sim = cv.Sim(pars=pars, people=people_copy, interventions=interventions, label=label)
        sim.initialize()
        if isinstance(initial_infections, (list, np.ndarray)):
            sim.people.infect(inds=initial_inf_uids)
        sims.append(sim)
        algo_names.append(algo_name)
    
    # No-vaccine baseline
    if isinstance(initial_infections, (list, np.ndarray)):
        init_label = f"community infection  {len(initial_infections)}"
    else:
        init_label = initial_infections
    people_no = copy.deepcopy(people)
    sim_no = cv.Sim(pars=pars, people=people_no, 
                    label=f"NoVax__{scenario_name}__init{init_label}")
    sim_no.initialize()
    if isinstance(initial_infections, (list, np.ndarray)):
        sim_no.people.infect(inds=initial_inf_uids)
    sims.append(sim_no)
    algo_names.append("NoVax")
    
    msim = cv.parallel(sims)
    legend_labels = []
    for algo in algo_names:
        legend_labels.append(f"{algo}")

    # Cumulative infections plot
    plt.figure(figsize=(9, 6))
    ax = plt.gca()
    for sim, lbl in zip(msim.sims, legend_labels):
        try:
            series = sim.results['cum_infections']
            days = np.arange(len(series))
            ax.plot(days, series, label=lbl)
        except Exception as e:
            print(f"Warning plotting cum_infections for {sim.label}: {e}")
    ax.set_xlabel("Day")
    ax.set_ylabel("Cumulative infections")
    if isinstance(initial_infections, (list, np.ndarray)):
        init_label = f"community infection + {len(initial_infections)}"
    else:
        init_label = initial_infections

    ax.set_title(f"Cumulative infections — scenario={scenario_name} | init={init_label}")    
    ax.legend(loc='best', fontsize='small')
    ax.grid(True)
    plt.tight_layout()
    plt.show()
    plt.close()

    
    plt.figure(figsize=(9, 6))
    ax = plt.gca()
    for sim, lbl in zip(msim.sims, legend_labels):
        try:
            series = sim.results['cum_deaths']
            days = np.arange(len(series))
            ax.plot(days, series, label=lbl)
        except Exception as e:
            print(f"Warning plotting cum_deaths for {sim.label}: {e}")
    ax.set_xlabel("Day")
    ax.set_ylabel("Cumulative deaths")
    ax.set_title(f"Cumulative deaths — scenario={scenario_name} | init={init_label}")
    ax.legend(loc='best', fontsize='small')
    ax.grid(True)
    plt.tight_layout()
    plt.show()
    
    
    runtime = time.time() - start_time
    
    return {
        "scenario": scenario_name,
        "initial_infections": initial_infections,
        "results": msim,
        "runtime_s": runtime
    }


def run_batch_experiments(people: cv.People,
                          selection_algo_names: List[str],
                          scenarios: List[Dict],
                          initial_infections_list: List[int],
                          n_days: int = 120,
                          base_seed: int = 42,
                          max_workers: int = None) -> List[Dict]:
    """
    Run batch experiments with optimizations:
    1. Compute vaccine orderings once per algorithm
    2. Run all algorithms in parallel using cv.parallel for each initialization
    
    Args:
        people: Population object
        selection_algo_names: List of algorithm names to test
        scenarios: List of scenario configurations
        initial_infections_list: List of initial infection counts
        n_days: Simulation duration
        base_seed: Base random seed
        max_workers: Max parallel workers (for different initializations)
    
    Returns:
        List of result dictionaries
    """
    if max_workers is None:
        max_workers = min(4, max(1, multiprocessing.cpu_count() - 1))
    
    # Filter to only requested algorithms
    selection_algos = {name: SELECTION_ALGOS[name] for name in selection_algo_names 
                      if name in SELECTION_ALGOS}
    
    # Pre-compute vaccine orderings once as it is independent of initialisations
    orderings = precompute_vaccine_orderings(people, selection_algos)
    
    # Build job list 
    jobs = []
    job_id = 0
    for scenario in scenarios:
        for init_inf in initial_infections_list:
            jobs.append({
                "people": people,
                "orderings": orderings,
                "scenario": scenario,
                "initial_infections": init_inf,
                "n_days": n_days,
                "seed": base_seed + job_id
            })
            job_id += 1
    
    # Run jobs (each job runs all algorithms in parallel via cv.parallel)
    results = []

    if max_workers == 1:
        # Sequential execution
        for job in jobs:
            result = run_one_initialization(**job)
            results.append(result)
    else:
        # Parallel execution of different initializations
        with ProcessPoolExecutor(max_workers=max_workers) as exe:
            future_to_job = {exe.submit(run_one_initialization, **job): job for job in jobs}
            for fut in as_completed(future_to_job):
                job = future_to_job[fut]
                try:
                    result = fut.result()
                    results.append(result)
                except Exception as e:
                    print(f"ERROR running initialization: {e}")
                    import traceback
                    traceback.print_exc()
    
    return results
