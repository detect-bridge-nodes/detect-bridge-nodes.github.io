import os
import copy
import pickle
from pathlib import Path
from typing import Callable, List, Tuple, Dict

import numpy as np
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
import re
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing
import random
import time

import community.community_louvain as community_louvain
from sir_implementation import *
# --------------------------------------------------------------------------------
# MAIN EXECUTION
# --------------------------------------------------------------------------------

if __name__ == "__main__":
    
    # Load data, change file name to use other dataset
    people_csv = "data/zenodo_people.csv"      #"data/synthetic_people.csv"      
    contacts_csv = "data/zenodo_network_all.csv"    #"data/synthetic_network_all.csv"

    print("\n" + "="*80)
    print("STEP 1: Building graph from CSV")
    print("="*80)
    G = build_graph_from_contacts(contacts_csv)
    set_global_graph(G)

    print("\n" + "="*80)
    print("STEP 2: Loading people data")
    print("="*80)
    df_people = pd.read_csv(people_csv)
    df_people.columns = df_people.columns.str.strip()

    # Sample ages as the people data is based on age group
    def sample_age_from_group(name):
        m = re.search(r"age_group_(\d+)_to_(\d+)", name)
        if m:
            low, high = int(m.group(1)), int(m.group(2))
            return np.random.randint(low, high+1)
        return np.random.randint(0, 91)

    np.random.seed(42)
    uids = df_people["# PersonID"].astype(int).to_numpy()
    ages = np.array([sample_age_from_group(x) for x in df_people["AgeGroup (Name)"]], dtype=int)

    print("\n" + "="*80)
    print("STEP 3: Precomputing vaccine orderings")
    print("="*80)
    
    # Define algorithms
    SELECTION_ALGOS = {
        "random": lambda: seq_random(list(G.nodes())),
        "degree": seq_degree,
        "wchb": seq_wchb,
        "bhd": seq_bhd,
        "age": lambda: prioritize_by_age(list(G.nodes()), {node_id: ages[node_id] for node_id in G.nodes()}),
        "mv": seq_mv,
        "cb": seq_cb
    }
    
    selection_names = ["random", "degree", "wchb", "bhd", "age", "mv", "cb"]
    selected_algos = {name: SELECTION_ALGOS[name] for name in selection_names}
    
    orderings = precompute_vaccine_orderings(G, ages, selected_algos)

    print("\n" + "="*80)
    print("STEP 4: Running experiments")
    print("="*80)
    
    # Change percentage to change vaccine availability
    scenarios = [
        {"name": "trickle", "daily_pct": 0.003},
        {"name": "front_load", "front_pct": 0.10, "front_days": 10}
    ]
    
    # Get initial infections from largest community
    comm_list, comm_map = get_community_map(G)
    largest_comm = max(comm_list, key=len)
    initial_infected_nodes = list(largest_comm)
    
    # Change values to change initial infections
    initial_infections_list = [
        random.sample(list(G.nodes()), 80),
        random.sample(list(G.nodes()), 160),
        initial_infected_nodes[:40],
        initial_infected_nodes[:80]
    ]
    
    # Run experiments
    all_results = []
    for scenario in scenarios:
        for init_inf in initial_infections_list:
            result = run_one_scenario(
                G=G,
                ages=ages,
                orderings=orderings,
                scenario=scenario,
                initial_infections=init_inf,
                n_days=180,
                seed=42
            )
            all_results.append(result)
    
    print("\n" + "="*80)
    print("All experiments completed!")
    print("="*80)
    