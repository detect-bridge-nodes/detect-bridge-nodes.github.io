from pathlib import Path
import numpy as np
import pandas as pd
import covasim as cv
import networkx as nx
import matplotlib.pyplot as plt
import re
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing
import random
import time

import community.community_louvain as community_louvain
from covasim_implementation import *

if __name__ == "__main__":

    # Map user-friendly names to functions
    SELECTION_ALGOS = {
        "random": seq_random,
        "degree": seq_degree,
        "wchb": seq_wchb,
        "bhd": seq_bhd,
        "cb": seq_cb,
        "mv": seq_mv,
        "age": prioritize_by_age
    }

    # Load data update to use other dataset
    people_csv = "data/zenodo_people.csv"      #"data/synthetic_people.csv"      
    contacts_csv = "data/zenodo_network_all.csv"    #"data/synthetic_network_all.csv"  

    # BUILD GRAPH FIRST (before creating people object)
    print("\n" + "="*80)
    print("STEP 1: Building graph from CSV")
    print("="*80)
    G = build_graph_from_contacts(contacts_csv)
    set_global_graph(G)  # Set global graph for sequence functions

    print("\n" + "="*80)
    print("STEP 2: Loading people data")
    print("="*80)
    df_people = pd.read_csv(people_csv)
    df_people.columns = df_people.columns.str.strip()

    def sample_age_from_group(name):
        m = re.search(r"age_group_(\d+)_to_(\d+)", name)
        if m:
            low, high = int(m.group(1)), int(m.group(2))
            return np.random.randint(low, high+1)
        return np.random.randint(0, 91)

    np.random.seed(42)
    uids = df_people["# PersonID"].astype(int).to_numpy()
    ages = np.array([sample_age_from_group(x) for x in df_people["AgeGroup (Name)"]], dtype=int)
    sexes = np.random.choice([0, 1], size=len(uids))

    print("\n" + "="*80)
    print("STEP 3: Building contact layers")
    print("="*80)
    # Build layers from contacts csv
    df_contacts = pd.read_csv(contacts_csv)
    df_contacts.columns = df_contacts.columns.str.strip()
    df_contacts = df_contacts.rename(columns={'PersonId1': 'pid1', 'PersonId2': 'pid2'})

    layers = {}
    for lname in df_contacts['LocationType'].unique():
        sub = df_contacts[df_contacts['LocationType'] == lname]
        layers[str(lname).strip()] = cv.Layer(
            p1=sub['pid1'].astype(int).to_numpy(),
            p2=sub['pid2'].astype(int).to_numpy(),
            beta=sub['Intensity'].astype(float).to_numpy()
        )

    contacts = cv.Contacts(layer_keys=[])
    if 'Home' in layers:
        contacts.add_layer(household=layers['Home'])
    if 'Work' in layers:
        contacts.add_layer(work=layers['Work'])
    if 'School' in layers:
        contacts.add_layer(school=layers['School'])
    if 'SocialEvent' in layers:
        contacts.add_layer(social=layers['SocialEvent'])
    if 'BasicsShop' in layers:
        contacts.add_layer(shop=layers['BasicsShop'])

    pop_size = len(uids)
    pars = dict(pop_size=pop_size, pop_infected=0, n_days=120)

    people = cv.People(pars=pars, uid=uids, age=ages, sex=sexes, contacts=contacts)

    print("\n" + "="*80)
    print("STEP 4: Running experiments")
    print("="*80)
    # Experiment configuration
    selection_names = ["random", "degree", "wchb", "bhd", "age", "mv"]
    scenarios = [
        {"name": "trickle", "daily_pct": 0.003},            
        {"name": "front_load", "front_pct": 0.10, "front_days": 10}  
    ]
    initial_infected_nodes = get_largest_community_leiden(G)
    initial_infections_list = [80, 160, initial_infected_nodes[:40], initial_infected_nodes[:80]]

    # Run experiments
    results = run_batch_experiments(
        people=people,
        selection_algo_names=selection_names,
        scenarios=scenarios,
        initial_infections_list=initial_infections_list,
        n_days=180,
        base_seed=42,
        max_workers=2  
    )